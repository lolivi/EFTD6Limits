#!/bin/bash

root -q -l bitops.cc++
root -q -l FinalStates.cc++
root -q -l cConstants.cc++
root -q -l Discriminants.cc++
root -q -l setTDRStyle.cpp++
