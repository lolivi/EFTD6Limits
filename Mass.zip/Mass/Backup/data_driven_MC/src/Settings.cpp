// Include classes
#include "Settings.h"

using namespace std;

// Constructor
//=====================
Settings::Settings() {}
//=====================


//======================
Settings::~Settings() {}
//======================