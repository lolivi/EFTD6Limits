// Include classes
#include "ZXVariables.h"

using namespace std;

// Constructor
//=======================
ZXVariables::ZXVariables() {}
//=======================


//========================
ZXVariables::~ZXVariables() {}
//========================
