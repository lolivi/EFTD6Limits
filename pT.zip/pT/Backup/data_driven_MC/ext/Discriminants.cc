#include "../include/Discriminants.h"
#include "../include/cConstants.h"

#include <cmath>

#include "TMath.h"
#include "TRandom3.h"

void Discriminants() {}

extern "C" float DVBF2j_ME(
                           float p_JJVBF_SIG_ghv1_1_JHUGen_JECNominal,
                           float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                           float ZZMass
                           )
{
   float c_Mela2j = 1;//getDVBF2jetsConstant(ZZMass);
   return 1./(1.+ c_Mela2j*p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal/p_JJVBF_SIG_ghv1_1_JHUGen_JECNominal);
}

extern "C" float DVBF1j_ME(
                           float p_JVBF_SIG_ghv1_1_JHUGen_JECNominal,
                           float pAux_JVBF_SIG_ghv1_1_JHUGen_JECNominal,
                           float p_JQCD_SIG_ghg2_1_JHUGen_JECNominal,
                           float ZZMass
                           )
{
   float c_Mela1j = 1;//getDVBF1jetConstant(ZZMass);
   return 1./(1.+ c_Mela1j*p_JQCD_SIG_ghg2_1_JHUGen_JECNominal/(p_JVBF_SIG_ghv1_1_JHUGen_JECNominal*pAux_JVBF_SIG_ghv1_1_JHUGen_JECNominal));
}

extern "C" float DWHh_ME(
                         float p_HadWH_SIG_ghw1_1_JHUGen_JECNominal,
                         float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                         float ZZMass
                         )
{
   float c_MelaWH =1;// getDWHhConstant(ZZMass);
   return 1./(1.+ c_MelaWH*p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal/p_HadWH_SIG_ghw1_1_JHUGen_JECNominal);
}

extern "C" float DZHh_ME(
                         float p_HadZH_SIG_ghz1_1_JHUGen_JECNominal,
                         float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                         float ZZMass
                         )
{
   float c_MelaZH = 1;//getDZHhConstant(ZZMass);
   return 1./(1.+ c_MelaZH*p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal/p_HadZH_SIG_ghz1_1_JHUGen_JECNominal);
}

float jetPgOverPq(float jetQGLikelihood, float jetPhi)
{
   if(jetQGLikelihood<0.){
      TRandom3 rand;
      rand.SetSeed(abs(static_cast<int>(sin(jetPhi)*100000)));
      return 1./rand.Uniform() - 1.;
   }else{
      return 1./jetQGLikelihood - 1.;
   }
}

extern "C" float DVBF2j_ME_QG(
                              float p_JJVBF_SIG_ghv1_1_JHUGen_JECNominal,
                              float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                              float ZZMass,
                              float* jetQGLikelihood,
                              float* jetPhi
                              )
{
   float DVBF2jME = DVBF2j_ME(p_JJVBF_SIG_ghv1_1_JHUGen_JECNominal, p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal, ZZMass);
   float GOverQ = TMath::Power( jetPgOverPq(jetQGLikelihood[0],jetPhi[0]) * jetPgOverPq(jetQGLikelihood[1],jetPhi[1]) , 1./3. );
   return 1./(1.+ (1./DVBF2jME - 1.) * GOverQ);
}

extern "C" float DVBF1j_ME_QG(
                              float p_JVBF_SIG_ghv1_1_JHUGen_JECNominal,
                              float pAux_JVBF_SIG_ghv1_1_JHUGen_JECNominal,
                              float p_JQCD_SIG_ghg2_1_JHUGen_JECNominal,
                              float ZZMass,
                              float* jetQGLikelihood,
                              float* jetPhi
                              )
{
   float DVBF1jME = DVBF1j_ME(p_JVBF_SIG_ghv1_1_JHUGen_JECNominal, pAux_JVBF_SIG_ghv1_1_JHUGen_JECNominal, p_JQCD_SIG_ghg2_1_JHUGen_JECNominal, ZZMass);
   float GOverQ = TMath::Power( jetPgOverPq(jetQGLikelihood[0],jetPhi[0]) , 1./3. );
   return 1./(1.+ (1./DVBF1jME - 1.) * GOverQ);
}

extern "C" float DWHh_ME_QG(
                            float p_HadWH_SIG_ghw1_1_JHUGen_JECNominal,
                            float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                            float ZZMass,
                            float* jetQGLikelihood,
                            float* jetPhi
                            )
{
   float DWHhME = DWHh_ME(p_HadWH_SIG_ghw1_1_JHUGen_JECNominal, p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal, ZZMass);
   float GOverQ = TMath::Power( jetPgOverPq(jetQGLikelihood[0],jetPhi[0]) * jetPgOverPq(jetQGLikelihood[1],jetPhi[1]) , 1./3. );
   return 1./(1.+ (1./DWHhME - 1.) * GOverQ);
}

extern "C" float DZHh_ME_QG(
                            float p_HadZH_SIG_ghz1_1_JHUGen_JECNominal,
                            float p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal,
                            float ZZMass,
                            float* jetQGLikelihood,
                            float* jetPhi
                            )
{
   float DZHhME = DZHh_ME(p_HadZH_SIG_ghz1_1_JHUGen_JECNominal, p_JJQCD_SIG_ghg2_1_JHUGen_JECNominal, ZZMass);
   float GOverQ = TMath::Power( jetPgOverPq(jetQGLikelihood[0],jetPhi[0]) * jetPgOverPq(jetQGLikelihood[1],jetPhi[1]) , 1./3. );
   return 1./(1.+ (1./DZHhME - 1.) * GOverQ);
}
