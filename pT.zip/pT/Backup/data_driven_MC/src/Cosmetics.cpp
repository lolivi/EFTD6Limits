// Include classes
#include "Cosmetics.h"

using namespace std;

// Constructor
//=======================
Cosmetics::Cosmetics() {}
//=======================


//========================
Cosmetics::~Cosmetics() {}
//========================