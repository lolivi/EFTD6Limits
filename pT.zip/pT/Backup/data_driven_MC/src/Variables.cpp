// Include classes
#include "Variables.h"

using namespace std;

// Constructor
//=======================
Variables::Variables() {}
//=======================


//========================
Variables::~Variables() {}
//========================